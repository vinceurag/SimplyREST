SimplyREST Contributors
============================================

* **[Vince Urag](https://github.com/vinceurag)**

  * Initial Work
