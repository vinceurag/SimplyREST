<?php

/**
 * Config files
 *
 * @author Vince Urag
 */

$config['base_url'] = "http://localhost/devspace/SimplyREST";

$config['JWT_CONSUMER_KEY'] = "YOUR-CONSUMER-KEY";

$config['JWT_SECRET_KEY'] = "YOUR-SECRET-KEY";
