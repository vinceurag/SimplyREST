<?php

/**
 * SimplyREST
 *
 * Define your custom constants here
 *
 * @author Vince Urag
 */

define("SAMPLE_CONST", "This is a sample value.");
