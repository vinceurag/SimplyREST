<?php
/**
 * Configure your database here
 *
 * @author Vince Urag
 */


$db['host'] = 'localhost';
$db['user'] = 'root';
$db['password'] = 'root';
$db['database'] = 'test_db';
